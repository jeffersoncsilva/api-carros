export interface Fabricante {
    id?: number;
    fabriNome: string;
}